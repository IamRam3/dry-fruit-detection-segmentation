# DryFruits-Detection > 2025-06-01 12:23am
https://universe.roboflow.com/cellsegment/dryfruits-detection-360ag

Provided by a Roboflow user
License: CC BY 4.0

