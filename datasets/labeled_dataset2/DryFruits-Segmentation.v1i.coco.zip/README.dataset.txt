# DryFruits-Segmentation > 2025-05-31 11:08am
https://universe.roboflow.com/cellsegment/dryfruits-segmentation

Provided by a Roboflow user
License: CC BY 4.0

