# DryFruits-classification > 2025-05-31 10:51am
https://universe.roboflow.com/cellsegment/dryfruits-classification

Provided by a Roboflow user
License: CC BY 4.0

