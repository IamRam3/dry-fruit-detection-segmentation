# DryFruits > 2025-05-30 3:05pm
https://universe.roboflow.com/cellsegment/dryfruits

Provided by a Roboflow user
License: CC BY 4.0

